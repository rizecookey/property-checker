/**
 * The implementation of the Fake Enum Checker.
 *
 * @checker_framework.manual #fenum-checker Fake Enum Checker
 */
package org.checkerframework.checker.fenum;
